//============================================================================
// Name        : kruskalprac.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <bits/stdc++.h>
#include <iostream>
using namespace std;
#define I 99
class graph{

	int **adjm;
	int size;

public:
	graph(int n){
		size = n;
		adjm = new int *[size];
		for(int i=0;i<size;i++)
		{
			adjm[i] = new int[size];
		}
		for(int i=0 ; i<size ;i++)
		{
			for(int j=0; j<size; j++)
			{
				adjm[i][j] = I;
			}
		}
	}

	void create()
	{
		int i,j,v,n,k;
		cout<<"Enter number of edges : ";
		cin>>n;

		for(int k=0; k<n ; k++)
		{
			cout<<"Enter src, dest, weight : ";
			cin>>i>>j>>v;

			adjm[i][j]=v;
			adjm[j][i]=v;
		}

		cout<<"\nCreated!!"<<endl;
	}

	void print_m()
	{
		for(int i=0 ; i<size; i++)
		{
			for(int j=0; j<size ; j++)
			{
				cout<<adjm[i][j] << " ";
			}
			cout<<endl;
		}
	}

	void kruskal()
	{
		vector<pair<int,pair<int,int>>>edges;
		int mincost = 0;

		//push edges in vector
		for(int i=0 ; i<size ; i++)
		{
			for(int j = i+1 ; j<size ; j++)
			{
				if(adjm[i][j]!=I){
					edges.push_back({adjm[i][j],{i,j}});
				}
			}
		}

		//sort according to weight
		sort(edges.begin(), edges.end());

		//parent array
		vector<int> parent(size);
		iota(parent.begin(), parent.end(), 0);

		// Find operation for disjoint sets : lamda function to find parent of given vertex
		function<int(int)> find = [&](int u){
			return (parent[u] == u) ? u : parent[u] = find(parent[u]);
		};

		//union operation for disjoint sets
		auto unify = [&](int u , int v){
			parent[find(u)] = find(v);
		};

		//kruskal algo
		for(auto edge : edges)
		{
			int weight = edge.first;
			int u = edge.second.first;
			int v = edge.second.second;

			if(find(u) != find(v))
			{
				mincost += weight;
				unify(u,v);
				cout<<"["<< u <<"]" <<"----"<<"["<< v <<"]"<<endl;
			}
		}

		cout<<"MST cost : "<<mincost<<endl;
	}
};
int main() {
	graph g(5);
	g.create();
	g.print_m();
	g.kruskal();
	return 0;
}
