using UnityEngine;
using UnityEngine.Video;

public class VideoPlayerController : MonoBehaviour
{
    private VideoPlayer videoPlayer;
    private void Start()
    {
        videoPlayer = GetComponent<VideoPlayer>();
    }

    private void Update()
    {
        if(Input.GetKeyDowm(KeyCode.LeftShift) || Input.GetKeyDowm(KeyCode.RightShift))
        {
           videoPlayer.Play()
        }
        else if(Input.GetKeyDowm(KeyCode.LeftAlt) || Input.GetKeyDowm(KeyCode.RightAlt))
        {
            videoPlayer.Stop()
        }
    }
}