using UnityEngine;

public class ObjectController : MonoBehaviour //this includes the methods like start, update, end, ontrigger i.e to attach custom behavior to game object
{
    private Transform selectedObject;
    private bool isObjectSelected = false;

    void Update()
    {
        // Select object by clicking on it
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit))
            {
                Transform objectHit = hit.transform;
                if (objectHit.CompareTag("Selectable"))
                {
                    SelectObject(objectHit);
                }
            }
        }

        // Change scale, rotation, and position of the selected object based on keyboard inputs
        if (isObjectSelected)
        {
            if (Input.GetKeyDown(KeyCode.A))
            {
                ChangeScale(selectedObject);
            }
            else if (Input.GetKeyDown(KeyCode.W))
            {
                RotateObject(selectedObject);
            }
            else if (Input.GetKeyDown(KeyCode.D))
            {
                ChangePosition(selectedObject);
            }
        }
    }

    void SelectObject(Transform obj)
    {
        selectedObject = obj;
        isObjectSelected = true;
    }

    void ChangeScale(Transform obj)
    {
        obj.localScale *= 1.1f; // Increase scale by 10%
    }

    void RotateObject(Transform obj)
    {
        obj.Rotate(Vector3.up, 10f); // Rotate around the y-axis clock wise by 10 degree
        //Vector3.right->x axis
        //Vector3.forward ->z axis
    }

    void ChangePosition(Transform obj)
    {
        obj.position += Vector3.right; // Move object along the x-axis
    }
}


using UnityEngine

public class TransformObj : MonoBehaviour
{
    private Transform selectedObject;
    private bool isObjectSelected = false;
    void Update()
    {
        if(GetMouseButtonDown(0))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if(Physics.Raycast(ray, out hit))
            {
                Transform objectHit = hit.transform
                if(objectHit.CompareTag("Selectable")){
                    SelectObject(objectHit)
                }
            }

        }

        if(isObjectSelected){
            if(Input.GetKeyDown(KeyCode.A))
            {
                ChangeScale(selectedObject)
            }
            else if(Input.GetKeyDown(KeyCode.R))
            {
                RotateObject(selectedObject)
            }
            else if(Input.GetKeyDown(KeyCode.P))
            {
                ChangePosition(selectedObject)
            }

        }
    }

    void SelectObject(Transform obj)
    {
        selectedObject = obj;
        isObjectSelected = true;
    }

    void ChangeScale(Transform obj)
    {
        obj.localScale *= 1.1f;
    }

    void RotateObject(Tranform obj)
    {
        obj.Rotate(Vector3.up, 10f);
    }

    void ChangePosition(Transform obj)
    {
        obj.position += Vector3.right;
    }

}