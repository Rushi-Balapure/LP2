import heapq

goal = []


class Node:
    def __init__(self, state, g, h):
        self.state = state
        self.g = g
        self.h = h

    def __lt__(self, other):
        return (self.g + self.h) < (other.g + other.h)


def astar():
    global goal
    start = []
    goal = []
    print("Enter start state : ")
    start = [list(map(int, input().split())) for _ in range(3)]

    print("Enter goal state matrix: ")
    goal = [list(map(int, input().split())) for _ in range(3)]

    start_node = Node(start, 0, heuristic(start, goal))
    frontier = []
    heapq.heappush(frontier, start_node)

    explored = set()

    while frontier:
        curr = heapq.heappop(frontier)

        print("Current state: ")
        print_matrix(curr.state)
        print("Heuristic:", curr.h)
        print("Path cost:", curr.g)

        if goal_test(curr):
            print("Goal found!")
            return curr

        explored.add(tuple(map(tuple, curr.state)))

        for neighbor in get_neighbors(curr):
            if tuple(map(tuple, neighbor.state)) not in explored:
                print("Generating moves:")
                print_matrix(neighbor.state)
                heapq.heappush(frontier, neighbor)

    print("Goal not found!")
    return None


def heuristic(state, goal):
    cost = 1
    for i in range(3):
        for j in range(3):
            if state[i][j] != goal[i][j] and state[i][j] != 0:
                cost += 1

    if cost == 1:
        return 0
    else:
        return cost


def get_neighbors(node):
    neighbors = []
    directions = [[1, 0], [-1, 0], [0, 1], [0, -1]]

    state = node.state
    row, col = find_empty(state)

    for dir in directions:
        r = row + dir[0]
        c = col + dir[1]

        if r >= 0 and r < 3 and c >= 0 and c < 3:
            n = swap(state, (row, col), (r, c))
            neighbors.append(Node(n, node.g + 1, heuristic(n, goal)))

    return neighbors


def find_empty(state):
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                return i, j


def swap(state, pos1, pos2):
    new_state = [r[:] for r in state]
    new_state[pos1[0]][pos1[1]], new_state[pos2[0]][pos2[1]] = new_state[pos2[0]][pos2[1]], new_state[pos1[0]][pos1[1]]
    return new_state


def goal_test(node):
    return node.state == goal


def print_matrix(matrix):
    for row in matrix:
        print(row)
    print()


astar()