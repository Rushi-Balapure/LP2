from collections import defaultdict

class Graph:
    def __init__(self):
        self.graph = defaultdict(list)

    def add_edge(self, u , v):
        self.graph[u].append(v)
        self.graph[v].append(u)

    def dfs_util(self, v , visited, level):
        visited[v]=True
        print(f"Node {v} at level {level}")
        for i in self.graph[v]:
            if not visited[i]:
                self.dfs_util(i,visited,level+1)


    def dfs(self,v):
        visited = [False] *len(self.graph)
        self.dfs_util(v,visited,0)


    def bfs(self, v):
        visited = [False] * len(self.graph)
        
        queue = []
        queue.append(v)
        visited[v] = True
        level = 0

        while queue:
            s = len(queue)
            print(f"Level {level} : " , end="")
            while s>0:
                v = queue.pop(0)
                print(f"{v}",end="")
                for i in self.graph[v]:
                    if not visited[i]:
                        queue.append(i)
                        visited[i] = True
                s -= 1
            print()
            level += 1

g = Graph()
n = int(input("Enter number of edges : "))

print("Enter edges (u v) : ")
for i in range(n):
    u,v = map(int, input().split())
    g.add_edge(u,v)

start = int(input("\nEnter starting vertex : "))

#print("\nDFS Traversal : ")
#g.dfs(start)

print("\nBFS Traversal :")
g.bfs(start)



        