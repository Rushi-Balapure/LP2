import random

# Function to convert input to lowercase
def to_lowercase(s):
    return s.lower()

def greet():
    """Greets the customer with a random welcome message."""
    greetings = ["Hello! Welcome to Myntra customer service. How can I assist you today?",
                "Hi there! Are you looking for information about a product or need help with your order?"]
    return greetings[random.randint(0, len(greetings)-1)]

def answer(question):
    """Provides a response to the customer's question based on keywords and placeholders."""
    # Match the question with the appropriate response
    if "delivery" in to_lowercase(question):
        response ="Delivery times typically range from {min_days} to {max_days} business days depending on your location and chosen shipping option. You can find more details on the product page"
    elif "return" in to_lowercase(question):
       response ="For hassle-free returns, you can visit our Returns Center at our official website"
    elif "track" in to_lowercase(question):
        response ="Absolutely! You can track your order by signing in to your myntra account and going to 'Your Orders'."
    elif "specific product" in to_lowercase(question):
        response ="Sure, tell me more about the product you're interested in.  What's the name or do you have a link?"
    elif "representative" in to_lowercase(question):
        response ="I understand. While I can answer most questions, you can connect with a live representative through our online chat option on the Myntra website."
    elif "order status" in to_lowercase(question):
       response ="To check your order status, can I get your order number?"
    elif "size chart" in to_lowercase(question):
        response ="You can refer to our size guide available on the product page to find the perfect fit."
    elif "discount" in to_lowercase(question):
        response ="hello there!! you will find details of discount and sales on homepage or while purchasing the product."
    elif "complaint" in to_lowercase(question):
        response ="I'm sorry to hear that. Please share your concern, and I'll do my best to assist you."
        
    elif "suggest" or "suggetion" or "opinion" or "suggestions" in to_lowercase(question):
        ch=int(input("Please Choose from :\n1.Western \n2.Traditional \n3.Indo-Western\n"))
        if ch==1:
            response = "You can try Crop top,baggy jeans\nAlso you can go with Oversized t-shirt and Cargo"
        elif ch==2:
            response="Anarkali\nGhagra\nSaree"
        elif ch==3:
            respose="Short kurti and jeans"
        else:
            response="Enter correct option"
    
    else:
        response ="I apologize, I couldn't quite understand that. Can you rephrase or ask something different? Perhaps you're looking for information about our popular categories like electronics or clothing?"
    
def main():
    """Runs the main loop of the chatbot interaction."""
    print(greet())

    while True:
        user_input = input("Customer: ")
        if user_input.lower() == "bye":
            print("Myntra Rep: Thank you for contacting Myntra! Have a great day.")
            break
        print("Myntra Rep:",answer(user_input))


if _name_ == "_main_":
    main()