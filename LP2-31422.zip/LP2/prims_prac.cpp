//============================================================================
// Name        : prims_prac.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <vector>
#include <map>
#include <climits>
using namespace std;
int V = 0;
map<string, int>city_item;

int minkey(vector<int> key, vector<bool> mstSet)
{
	int min = INT_MAX, min_index;
	for(int v=0; v<V; v++)
	{
		if(mstSet[v] == false && key[v]<min)
		{
			min = key[v];
			min_index = v;
		}
	}
	return min_index;
}

void printMST(vector<int>parent, vector<vector<int>>graph)
{
	cout<<"Edge \t Weight\n";
	for(int i=1 ; i<V; i++)
	{
		cout<<parent[i]<<"-"<<i<<"\t"<<
				graph[i][parent[i]]<<"\n";
	}
}

int primMST(vector<vector<int>>graph)
{
	vector<int> parent(V);
	vector<int> key(V);
	vector<bool> mstSet(V);

	for(int i=0 ; i<V; i++)
	{
		key[i] = INT_MAX;
		mstSet[i] = false;
	}

	key[0] = 0;
	parent[0] = -1;

	for(int i=0; i<V-1; i++)
	{
		int u = minkey(key,mstSet);
		mstSet[u] = true;

		for(int v=0 ; v<V ; v++)
		{
			if(graph[u][v] && mstSet[v] == false && graph[u][v]<key[v])
			{
				parent[v] = u;
				key[v] = graph[u][v];
			}
		}
	}

	printMST(parent,graph);
	int totalCost = 0;
	for (int i = 1; i < V; i++) {
	    totalCost += graph[i][parent[i]];
	}
	return totalCost;
}
int main() {
	string c1,c2;
	int wt;
	cout<<"Enter no of cities :";
	cin>>V;

	vector<vector<int>>graph(V,vector<int>(V,0));
	cout<<"Enter the cities : "<<endl;
	for(int i = 0; i<V; i++)
	{
		string temp;
		cout<<"Enter city "<<i+1<<":";
		cin>>temp;
		city_item[temp]=i;
	}

	int e;
	cout<<"Enter number of edges : ";
	cin>>e;
	for(int i=0;i<e;i++)
	{
		cout<<"Edge "<<i+1<<endl;
		cout<<"Enter city 1 : ";
		cin>>c1;
		cout<<"Enter city 2 : ";
		cin>>c2;
		cout<<"Enter travel cost  : ";
		cin>>wt;

		graph[city_item[c1]][city_item[c2]]=wt;
		graph[city_item[c2]][city_item[c1]]=wt;
	}
	int totalCost = primMST(graph);
	cout << "Total cost of the Minimum Spanning Tree: " << totalCost << endl;

	return 0;
}
