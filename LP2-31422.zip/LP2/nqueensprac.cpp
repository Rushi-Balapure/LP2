//============================================================================
// Name        : nqueensprac.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool isSafe(int row, int col, vector<vector<int>>&board , int n){

	for(int i=0; i<n; i++)
	{
		if(board[row][i]==1 || board[i][col]==1) return false;
	}

	//check diagonals

	//top left(i>=0 && j>=0)
	int i=row, j=col;
	while(i>=0 && j>=0)
	{
		if(board[i][j] == 1)return false;
		i--;
		j--;
	}

	//bottom left(i<n && j>=0)
    i = row, j = col;
    while(i<n && j>=0)
    {
    	if(board[i][j] == 1)return false;
    	i++;
    	j--;
    }

	//top right(i>=0 && j<n)
    i  = row, j= col;
    while(i>=0 && j<n)
    {
    	if(board[i][j]==1)return false;
    	i--;
    	j++;
    }

	//bottom right(i<n && j<n)
    i = row, j= col;
    while(i<n && j<n)
    {
    	if(board[i][j] == 1)return false;
    	i++;
    	j++;
    }
    return true;
}

bool solveNQueensBackTrack(vector<vector<int>>&board, int col , int n)
{
	if(col>=n)
	{
		return true;
	}

	for(int i=0; i<n ; i++)
	{
		if(isSafe(i,col,board,n)){
			board[i][col] = 1;

			if(solveNQueensBackTrack(board, col+1 , n)){
				return true;
			}

	    board[i][col] = 0;
		}
	}
	return false;
}

bool solveNQueensBranchandBound(vector<vector<int>>&board, int col, int n)
{
	if(col>=n)
	{
		return true;
	}

	vector<pair<int, int>> available_positions;
	for(int i=0 ; i<n; i++)
	{
		if(isSafe(i, col, board, n)){

			int count = 0;
			for(int j=0 ; j<n ; j++)
			{
				if(board[i][j]==0) count++;
			}
			available_positions.push_back({count,i});
		}
	}

	sort(available_positions.begin(), available_positions.end());

	for(auto& pos : available_positions){
		int row = pos.second;
		board[row][col] = 1;

		if(solveNQueensBranchandBound(board, col+1, n)){
			return true;
		}

		board[row][col] = 0;
	}
	return false;
}
void printSol(const vector<vector<int>> &board, int n)
{
	for(int i=0 ; i<n; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			cout<<board[i][j]<<" ";
		}
		cout<<endl;
	}
}
int main() {
	int n;
	cout << "Enter board size : " << endl;
	cin >> n;

	vector<vector<int>> board(n,vector<int>(n,0));
	if(solveNQueensBackTrack(board,0,n)){
		cout<<"Backtracking solution is : "<<endl;
		printSol(board,n);
	}
	else{
		cout<<"Backtracking : No solution exist "<<endl;
	}

	board.assign(n,vector<int>(n,0));
	if(solveNQueensBranchandBound(board,0,n)){
		cout<<"Branch And Bound solution is : "<<endl;
		printSol(board,n);
	}
	else{
			cout<<"Backtracking : No solution exist "<<endl;
		}
	return 0;
}
