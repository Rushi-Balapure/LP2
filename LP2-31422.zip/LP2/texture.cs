using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextureChange : MonoBehaviour
{
    public Texture[] textures; // Array of textures
    public int x; // Index to track current texture
    Renderer rend;

    void Start()
    {
        x = 0;
        rend = GetComponent<Renderer>();
        rend.enabled = true;
        rend.material.mainTexture = textures[x]; // Assign the initial texture
    }

    void Update()
    {
        // You can remove this line unless you want to constantly update the texture in Update()
        // rend.material.mainTexture = textures[x];
    }

    public void NextTexture()
    {
        x = (x + 1) % textures.Length; // Cycle through the textures
        rend.material.mainTexture = textures[x]; // Assign the next texture
    }
}